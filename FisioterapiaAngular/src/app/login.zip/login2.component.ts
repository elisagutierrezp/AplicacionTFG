import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './user/login.component.html',
  styleUrls: ['./user/login.component.css']
})
export class LoginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
